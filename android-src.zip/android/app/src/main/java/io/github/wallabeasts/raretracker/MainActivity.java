package io.github.wallabeasts.raretracker;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;
import android.window.OnBackInvokedDispatcher;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.CancellationSignal;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Rare Disease Tracker, as an Android app.
 *
 * The whole app (index.html and the language files) is packed inside this APK, under assets/.
 * The app itself is never fetched from a website: it works with the phone in airplane mode, and the
 * patient's record never leaves the phone. The internet is used only for trial alerts, articles and fonts.
 *
 * The pages reach the WebView through WebViewAssetLoader, so they arrive over
 * https://appassets.androidplatform.net/ rather than file://. That matters: an https origin is a
 * "secure context", which the browser requires before handing the app the encryption
 * (crypto.subtle) and storage it uses to lock the record with the patient's password.
 */
public class MainActivity extends Activity {

    private static final String DOMAIN = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + DOMAIN + "/assets/index.html";
    private static final int PICK_FILE = 1;

    private WebView web;
    private ValueCallback<Uri[]> filePicker;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(DOMAIN)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);

        // Android 15 and newer draw apps under the status and navigation bars. The frame keeps the page clear
        // of them (and of the keyboard) by padding itself to the bars' size; the strips behind the bars stay black.
        final FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Color.BLACK);
        frame.addView(web, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(frame);
        if (Build.VERSION.SDK_INT >= 30) {
            frame.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return WindowInsets.CONSUMED;
            });
            WindowInsetsController bars = getWindow().getInsetsController();
            if (bars != null) bars.setSystemBarsAppearance(0,
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        }

        // The phone's Back gesture goes back inside the app first, then closes it.
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    () -> { if (web.canGoBack()) web.goBack(); else finish(); });
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage: where the locked record is kept
        s.setAllowFileAccess(false);           // nothing outside the packed assets
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);
        // Follow the phone's own font size setting (Settings > Display > Font size), for people with low vision.
        s.setTextZoom(Math.round(getResources().getConfiguration().fontScale * 100));

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                return loader.shouldInterceptRequest(req.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (u != null && DOMAIN.equals(u.getHost())) return false; // our own pages
                handOff(u);                                                // links and mailto: leave the app
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            // "Choose a backup file" and "Open a shared copy" need the phone's own file picker.
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePicker != null) filePicker.onReceiveValue(null);
                filePicker = cb;
                try {
                    startActivityForResult(params.createIntent(), PICK_FILE);
                } catch (ActivityNotFoundException e) {
                    filePicker = null;
                    toast("No app on this phone can pick a file.");
                    return false;
                }
                return true;
            }
        });

        // Exports (backup .json, spreadsheet .csv) are saved through this, because a WebView has
        // no Downloads folder of its own. The page calls it when running inside this app.
        web.addJavascriptInterface(new Exporter(), "AndroidExport");

        // Fingerprint (or strong face) unlock for the record. See BioBridge below and src/native.js.
        web.addJavascriptInterface(new BioBridge(), "AndroidBio");

        // Patient portal (Epic MyChart): the sign-in page opens in the phone's browser, and the health system's
        // requests are made by the app (see PortalBridge below and src/native.js).
        web.addJavascriptInterface(new PortalBridge(), "AndroidPortal");

        if (saved != null) web.restoreState(saved);
        else web.loadUrl(START_URL);
    }

    // Back from the patient portal's sign-in page (com.myrarediseasetracker.app://oauth/...): hand the address,
    // with its one-time code, to the page.
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Uri u = intent == null ? null : intent.getData();
        if (u == null || !"com.myrarediseasetracker.app".equals(u.getScheme())) return;
        final String js = "window.__rdtPortalBack && window.__rdtPortalBack(" + org.json.JSONObject.quote(u.toString()) + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_FILE || filePicker == null) return;
        filePicker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
        filePicker = null;
    }

    private void handOff(Uri u) {
        if (u == null) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (ActivityNotFoundException e) {
            toast("No app on this phone can open that.");
        }
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_LONG).show();
    }

    /** Writes an exported backup or spreadsheet into the phone's Downloads folder. */
    public class Exporter {
        @JavascriptInterface
        public void saveText(String text, String filename, String mime) {
            writeDownload(text == null ? new byte[0] : text.getBytes(StandardCharsets.UTF_8), filename, mime);
        }

        /** A binary file from the page (like the Trends PDF), passed as base64 text. */
        @JavascriptInterface
        public void saveBase64(String b64, String filename, String mime) {
            byte[] bytes;
            try {
                bytes = android.util.Base64.decode(b64 == null ? "" : b64, android.util.Base64.DEFAULT);
            } catch (Exception e) {
                runOnUiThread(() -> toast("That file couldn't be saved."));
                return;
            }
            writeDownload(bytes, filename, mime);
        }

        private void writeDownload(byte[] bytes, String filename, String mime) {
            String name = (filename == null || filename.trim().isEmpty())
                    ? "rare-disease-tracker-export.json" : filename.trim();
            boolean ok = true;
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE,
                        (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime);
                v.put(MediaStore.Downloads.IS_PENDING, 1);

                Uri item = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (item == null) {
                    ok = false;
                } else {
                    OutputStream out = getContentResolver().openOutputStream(item);
                    if (out == null) {
                        ok = false;
                    } else {
                        out.write(bytes);
                        out.close();
                    }
                    v.clear();
                    v.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(item, v, null, null);
                }
            } catch (Exception e) {
                ok = false;
            }
            final String message = ok ? "Saved to Downloads: " + name : "That file couldn't be saved.";
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    toast(message);
                }
            });
        }
    }

    /**
     * Fingerprint / face unlock. A random secret from the page is locked with a key kept in the Android Keystore.
     * That key only works after a strong fingerprint or face check, and Android deletes it if the enrolled
     * fingerprints or faces change. The locked secret is kept in this app's private storage. Nothing leaves the phone.
     * Results go back to the page through window.__rdtNativeBio(id, ok, value, code).
     */
    public class BioBridge {
        private static final String KEY_PREFIX = "rdt_bio_";
        private static final String PREFS = "rdt_bio";

        @JavascriptInterface
        public String available() {
            try {
                BiometricManager bm = getSystemService(BiometricManager.class);
                if (bm == null) return "no";
                int r = Build.VERSION.SDK_INT >= 30
                        ? bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                        : bm.canAuthenticate();
                return r == BiometricManager.BIOMETRIC_SUCCESS ? "yes" : "no";
            } catch (Exception e) {
                return "no";
            }
        }

        @JavascriptInterface
        public void save(final int id, final String key, final String value, final String prompt) {
            runOnUiThread(() -> {
                try {
                    SecretKey k = newKey(KEY_PREFIX + key);
                    Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                    c.init(Cipher.ENCRYPT_MODE, k);
                    ask(id, c, prompt, cipher -> {
                        byte[] out = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
                        prefs().edit()
                                .putString(key + ".iv", Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP))
                                .putString(key + ".data", Base64.encodeToString(out, Base64.NO_WRAP))
                                .apply();
                        return "";
                    });
                } catch (Exception e) {
                    reply(id, false, "", "unavailable");
                }
            });
        }

        @JavascriptInterface
        public void load(final int id, final String key, final String prompt) {
            runOnUiThread(() -> {
                String iv = prefs().getString(key + ".iv", null);
                String data = prefs().getString(key + ".data", null);
                if (iv == null || data == null) { reply(id, false, "", "changed"); return; }
                try {
                    KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
                    ks.load(null);
                    SecretKey k = (SecretKey) ks.getKey(KEY_PREFIX + key, null);
                    if (k == null) { reply(id, false, "", "changed"); return; }
                    Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                    c.init(Cipher.DECRYPT_MODE, k, new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
                    ask(id, c, prompt, cipher -> new String(
                            cipher.doFinal(Base64.decode(data, Base64.NO_WRAP)), StandardCharsets.UTF_8));
                } catch (KeyPermanentlyInvalidatedException e) {
                    forget(key);
                    reply(id, false, "", "changed");
                } catch (Exception e) {
                    reply(id, false, "", "failed");
                }
            });
        }

        @JavascriptInterface
        public void remove(final int id, final String key) {
            forget(key);
            reply(id, true, "", "");
        }

        private SharedPreferences prefs() {
            return getSharedPreferences(PREFS, MODE_PRIVATE);
        }

        private void forget(String key) {
            prefs().edit().remove(key + ".iv").remove(key + ".data").apply();
            try {
                KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
                ks.load(null);
                ks.deleteEntry(KEY_PREFIX + key);
            } catch (Exception e) {
                // already gone
            }
        }

        private SecretKey newKey(String alias) throws Exception {
            KeyGenParameterSpec.Builder b = new KeyGenParameterSpec.Builder(alias,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .setUserAuthenticationRequired(true)
                    .setInvalidatedByBiometricEnrollment(true);
            if (Build.VERSION.SDK_INT >= 30) {
                b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG);
            }
            KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            g.init(b.build());
            return g.generateKey();
        }

        private void ask(final int id, Cipher cipher, String prompt, final Step step) {
            BiometricPrompt.Builder b = new BiometricPrompt.Builder(MainActivity.this)
                    .setTitle(prompt == null || prompt.isEmpty() ? "Open your record" : prompt)
                    .setNegativeButton("Use password", getMainExecutor(),
                            (dialog, which) -> reply(id, false, "", "cancelled"));
            if (Build.VERSION.SDK_INT >= 30) b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG);
            b.build().authenticate(new BiometricPrompt.CryptoObject(cipher), new CancellationSignal(), getMainExecutor(),
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            try {
                                reply(id, true, step.run(result.getCryptoObject().getCipher()), "");
                            } catch (Exception e) {
                                reply(id, false, "", "failed");
                            }
                        }

                        @Override
                        public void onAuthenticationError(int code, CharSequence msg) {
                            boolean cancelled = code == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED
                                    || code == BiometricPrompt.BIOMETRIC_ERROR_CANCELED;
                            reply(id, false, "", cancelled ? "cancelled" : "failed");
                        }
                    });
        }

        private void reply(final int id, final boolean ok, final String value, final String code) {
            final String js = "window.__rdtNativeBio && window.__rdtNativeBio(" + id + "," + ok + ","
                    + quote(value) + "," + quote(code) + ")";
            runOnUiThread(() -> web.evaluateJavascript(js, null));
        }

        private String quote(String v) {
            // Values are base64 or short codes; escape anyway.
            return "\"" + (v == null ? "" : v.replace("\\", "\\\\").replace("\"", "\\\"")) + "\"";
        }
    }

    /** Patient portal sign-in and requests. Only https addresses; nothing is stored. */
    public class PortalBridge {
        @JavascriptInterface
        public void open(String url) {
            Uri u = Uri.parse(url);
            if (!"https".equals(u.getScheme())) return;
            runOnUiThread(() -> handOff(u));
        }

        @JavascriptInterface
        public void request(final int id, final String url, final String method, final String headersJson, final String body) {
            new Thread(() -> {
                int status = 0;
                String text = "";
                String err = "";
                java.net.HttpURLConnection c = null;
                try {
                    java.net.URL u = new java.net.URL(url);
                    if (!"https".equals(u.getProtocol())) throw new java.io.IOException("https only");
                    c = (java.net.HttpURLConnection) u.openConnection();
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(20000);
                    c.setUseCaches(false);
                    c.setInstanceFollowRedirects(true);
                    boolean post = "POST".equalsIgnoreCase(method);
                    c.setRequestMethod(post ? "POST" : "GET");
                    org.json.JSONObject h = new org.json.JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                    java.util.Iterator<String> keys = h.keys();
                    while (keys.hasNext()) { String k = keys.next(); c.setRequestProperty(k, h.optString(k)); }
                    if (post) {
                        c.setDoOutput(true);
                        try (OutputStream o = c.getOutputStream()) { o.write((body == null ? "" : body).getBytes(StandardCharsets.UTF_8)); }
                    }
                    status = c.getResponseCode();
                    java.io.InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    if (in != null) {
                        java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
                        byte[] b = new byte[16384];
                        int n;
                        while ((n = in.read(b)) > 0 && buf.size() < 20_000_000) buf.write(b, 0, n);
                        in.close();
                        text = buf.toString("UTF-8");
                    }
                } catch (java.net.SocketTimeoutException e) {
                    err = "timeout";
                } catch (Exception e) {
                    err = "unreachable";
                } finally {
                    if (c != null) c.disconnect();
                }
                final String js = "window.__rdtNativeHttp && window.__rdtNativeHttp(" + id + "," + status + ","
                        + org.json.JSONObject.quote(text) + "," + org.json.JSONObject.quote(err) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }
    }

    private interface Step {
        String run(Cipher cipher) throws Exception;
    }
}
